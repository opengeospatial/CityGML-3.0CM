This folder contains XMI files exported from the CityGML 3.0 conceptual model (UML model) using Enterprise Architect version 14.
This includes
- a single XMI file version with all packages integrated
- a per-package collection of XMI files for each package in the UML model
- XMI files for the ISO TC211 and OASIS references
